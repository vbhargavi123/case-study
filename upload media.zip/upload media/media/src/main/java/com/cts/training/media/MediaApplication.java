package com.cts.training.media;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.ConfigurableEnvironment;

import feign.Request;
@EnableFeignClients("com.cts.training.media.feignproxy")
@EnableEurekaClient
@SpringBootApplication

public class MediaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MediaApplication.class, args);
	}
	@Bean
	Request.Options requestOptions(ConfigurableEnvironment env){
		int ribbonReadTimeOut =env.getProperty("ribbon.ReadTimeOut",int.class,6000);
		int ribbonConmnectionTimeOut =env.getProperty("ribbon.ConnectionTimeOut",int.class,3000);
		
		return new Request.Options(ribbonConmnectionTimeOut,ribbonReadTimeOut);
	}

}
