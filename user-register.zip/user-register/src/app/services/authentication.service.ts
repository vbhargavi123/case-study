import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient, HttpInterceptor } from '@angular/common/http';
import {map} from 'rxjs/operators';
import { UserRegistrationDetails } from '../model/user-registration';
import { UserRegistrationService } from './user-registration.service';

const VALIDATION_URL = "http://localhost:8765/user-service/users";

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  id:number;
  userlist:Array<UserRegistrationDetails>
  constructor(public http : HttpClient,public service:UserRegistrationService) {
    this.service.getAllUsers().subscribe((Response:any)=>{this.userlist=Response;console.log(Response)});
   }

  authenticate(userid : string, password : string):boolean{
    // create a security token
    let authenticationToken = "Basic " + window.btoa(userid + ":" + password);
    console.log("service");
    console.log(userid);
    console.log(password);
    console.log(this.userlist)
    for(let u of this.userlist){
      console.log(u)
      if(userid === u.userName && password === u.password){
        sessionStorage.setItem("user", u.userName);
        sessionStorage.setItem("uid", String(u.id));
        console.log("authenticate="+this.id)
        console.log("Logged in")
        return true;

    }
  }
  return false;
}




getId():string{
  let user = sessionStorage.getItem('userid');
  return user;
}
  

  // to check if user if logged in or not
  isUserLoggedIn(): boolean{
    // check if sessionStorage contains key 'user'
    let user = sessionStorage.getItem('user');
    if(user == null)
      return false;
    return true;  
  }

  // logout
  logout(){
    // remove the key/value pair of 'user'
//    sessionStorage.removeItem('token')
    sessionStorage.removeItem('user');
    // sessionStorage.clear();
  }

  // get user Details
  getUserDetails():string{
    let user = sessionStorage.getItem('user');
    return user;
  }
}
