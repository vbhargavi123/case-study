package com.cts.training.userservice.controller;


import java.nio.charset.StandardCharsets;
import java.util.Base64;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cts.training.userservice.entity.User;
import com.cts.training.userservice.model.ResponseData;
import com.cts.training.userservice.model.UserInput;

import com.cts.training.userservice.repository.UserRepository;
import com.cts.training.userservice.service.IUserService;
import com.cts.training.userservice.service.StorageService;

@RestController
@CrossOrigin("http://localhost:4200")
public class LoginController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	// testing end-point
	@Autowired
	private IUserService userservice;
	@Autowired
	private  UserRepository  userRepository;
	@Autowired
	private StorageService storageService;
	
	@PostMapping("/test")
	public boolean test(@RequestParam("file") MultipartFile file)
	{
		this.storageService.store(file);
		return true;
	}
	@GetMapping("/login")
	public ResponseEntity<ResponseData> login(HttpServletRequest request) {
		String authorization = request.getHeader("Authorization");
		String[] values = null;

		if (authorization != null && authorization.startsWith("Basic")) {
		    // Authorization: Basic base64credentials
		    String base64Credentials = authorization.substring("Basic".length()).trim();
		    byte[] credDecoded = Base64.getDecoder().decode(base64Credentials);
		    String credentials = new String(credDecoded, StandardCharsets.UTF_8);
		    // credentials = username:password
		    values = credentials.split(":", 2);
		
		
		}
		
		
		
		// if called then credentials are valid
		logger.info("Logged In...");
		logger.info(values[0]);
		logger.info(values[1]);

        User user = this.userRepository.findByUsername(values[0]).get(0);
        logger.info("User : " + user);
		
		ResponseData data = new ResponseData("Welcome!!!", System.currentTimeMillis(),user.getId(),user.getProfile());

		ResponseEntity<ResponseData> response = 
					new ResponseEntity<ResponseData>(data, HttpStatus.OK);
		
		return response;
	} 
	
	@PostMapping("/register")
	public ResponseEntity<UserInput> register(@RequestParam("file") MultipartFile file,@RequestParam("username") String username,@RequestParam("password") String password,@RequestParam("email") String email,@RequestParam("profile") String profile)
		// if called then credentials are valid
	{
		logger.info("Registration...");
		UserInput userInput=new UserInput(username,password,email,profile);
	
		this.userservice.addUser(userInput);
		this.storageService.store(file);
		
		ResponseEntity<UserInput> response = 

					new ResponseEntity<UserInput>(userInput, HttpStatus.OK);
		return response;

}

}