import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { SearchedUserModel } from '../model/SearchedUserModel.model';
import { SearchedUserModelList } from '../model/SearchedUserModelList.model';
import { Router } from '@angular/router';
import { UserRegistrationService } from '../services/user-registration.service';
import { UserserviceService } from '../services/DataServices/userservice.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  searchtext : string;
  myFormGroup : FormGroup;
  result : string ;
  userList : Array<SearchedUserModel>;
  constructor(formbuilder : FormBuilder, public router: Router, private userserviceService: UserserviceService) {
    
    this.myFormGroup = formbuilder.group(
      {
        "keyword" : new FormControl(),
      }
    );

   }

   search(){
     this.searchtext = this.myFormGroup.controls['keyword'].value;
     this.userserviceService.getSearchResult(this.searchtext).subscribe(
      (response : SearchedUserModelList) => {
        this.userList = response.userList;
        this.userList = this.userList.map(user =>{
          user.profileUrl = "http://localhost:8765/user-service/"+user.profileUrl;
          return user;
        });
        
      }
    );
   }

   

  ngOnInit() {
  }

}

