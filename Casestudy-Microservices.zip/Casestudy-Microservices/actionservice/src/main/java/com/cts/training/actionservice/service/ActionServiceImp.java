package com.cts.training.actionservice.service;

public class ActionServiceImp implements IActionService {

}
