import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserRegistrationDetails } from 'src/app/model/user-registration';
import { Observable } from 'rxjs';
import { SearchedUserModelList } from 'src/app/model/SearchedUserModelList.model';
import { UserAuthService } from '../user-auth.service';
import { RetrieveMedia } from 'src/app/model/RetrieveMedia.model';
import { NewsFeed } from 'src/app/model/NewsFeed.model';
const API_URL = "http://localhost:8765/user-service/users";
const REG_URL = "http://localhost:8765/user-service/register";
const UsernamesURL="http://localhost:8765/user-service/username";
const MISC_URL="http://localhost:8765/misc-plumbling";
@Injectable({
  providedIn: 'root'
})


export class UserserviceService {
  
  news_feed="http://localhost:9091/newsfeeds/"
  Url="http://localhost:8765/misc-plumbing/searched-users/"
  Ret_url="http://localhost:8765/media-plumbing/media/"
  constructor(public http : HttpClient) {


   }

  getAllUsers():any{
    return this.http.get(API_URL);
  }

  getUser(id:number):any{
    return this.http.get(API_URL+"/"+id);
  }

  addUser(user:UserRegistrationDetails):any{
    return this.http.post(REG_URL,user);
  }

  delete(id:number){
    this.http.delete(API_URL+"/"+id);
  }

  update(id:number,user:UserRegistrationDetails):any{
    return this.http.put(API_URL+"/"+id,user);
  }
  getSearchResult(searchText:string):Observable<SearchedUserModelList>
  {
    return this.http.get<SearchedUserModelList>(this.Url+searchText+"/myid/"+(sessionStorage.getItem('userId')));
  }
  // getSearchedUsers(searchText:string){
  //   return this.http.get(MISC_URL + "/Searched-users/" +searchText +"/myid/"+);
  // }
  getAllUsernames():any{
    return this.http.get(UsernamesURL);
  }
  getAllMedia(userid:string):Observable<RetrieveMedia[]>
  {
    return this.http.get<RetrieveMedia[]>(this.Ret_url+userid);
  }
  getAllFeed(userid:string):Observable<NewsFeed[]>
  {
    return this.http.get<NewsFeed[]>(this.news_feed+userid);
  }
 

}
