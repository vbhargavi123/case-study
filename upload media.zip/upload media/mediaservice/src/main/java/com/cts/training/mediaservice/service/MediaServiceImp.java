package com.cts.training.mediaservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.training.mediaservice.entity.Media;
import com.cts.training.mediaservice.model.MediaData;
import com.cts.training.mediaservice.model.MediaDataModel;
import com.cts.training.mediaservice.repository.MediaRepository;

@Service
public class MediaServiceImp implements IMediaService {
	@Autowired 
	private MediaRepository mediaRepository;
	
	
	

	@Override
	public List<Media> getall() {
		List<Media> records=new ArrayList<Media>();
		records=this.mediaRepository.findAll();
		// TODO Auto-generated method stub
		return records;
	}

	@Override
	public void save(MediaDataModel media) {
		
		Media data=new Media();
		data.setUserId(media.getUserId());
		data.setTitle(media.getTitle());
		data.setDescription(media.getDescription());
		data.setFileUrl(media.getUrl());
		data.setTags(media.getTags());
		data.setMimeType(media.getType());
		this.mediaRepository.save(data);
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public Optional<Media> getWithId(Integer id) {
		Optional<Media> record=this.mediaRepository.findById(id);
		// TODO Auto-generated method stub
		return record;
	}

	@Override
	public void updateuser(MediaData media) {
		
		Media data=new Media();
		data.setUserId(media.getId());
		data.setTitle(media.getTitle());
		data.setDescription(media.getDescription());
		data.setFileUrl(media.getFile());
		data.setTags(media.getTags());
		data.setMimeType(media.getType());
		this.mediaRepository.save(data);
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public void save(MediaData action) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	

}
