import { Component, OnInit } from '@angular/core';
import{FormGroup, FormControl, FormBuilder, Validators} from'@angular/forms';

import { Router } from '@angular/router';
import { UserRegistrationService } from 'src/app/services/user-registration.service';
import { UserRegistrationDetails } from 'src/app/model/user-registration';
import { UserserviceService } from 'src/app/services/DataServices/userservice.service';

import { AuthenticationService } from 'src/app/services/authentication.service';
import { HttpResponse, HttpEventType,HttpEvent } from '@angular/common/http';
import { UploadMediaService } from 'src/app/services/upload/upload-media.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  
  public imagePath;
  imgURL: any;
  public message: string;

  selectedFiles: FileList;
  currentFileUpload: File;
  // dynamic class containing only one field 
  // anonymous class
  progress: { percentage: number } = { percentage: 0 };

  
  userId : string;
  url : string;
  date : Date;

  submitted : boolean = false;

  
  userName : string;
  email : string;
  password : string;
  
  profilePic : any;
  avilable:string="";
  validate : boolean=false;
  myFormGroup : FormGroup;
  userlist : Array<UserRegistrationDetails>;
  constructor(public details : UserRegistrationService,public auth : AuthenticationService,public uploadService : UploadMediaService  ,public router : Router, formBuilder: FormBuilder,public ser : UserserviceService) {
    console.log("in form bilder of reg");
    this.myFormGroup=formBuilder.group({
      
      "userName" : new FormControl(""),
      "email" : new FormControl(""),
      "password" : new FormControl(""),
      "repassword" : new FormControl(""),
      "profilePic" : new FormControl("")
    });

  }
  
  get f(){return this.myFormGroup.controls;}
  selectFile(event) {
    this.selectedFiles = event.target.files;
  }
  
  
  reg(){
    console.log("Registration method");
    this.submitted = true;
    if(this.myFormGroup.valid){
    
   
    this.userName=this.myFormGroup.controls['userName'].value;
    this.password=this.myFormGroup.controls['password'].value;
    console.log(this.password);
    
    this.email=this.myFormGroup.controls['email'].value;
    this.currentFileUpload = this.selectedFiles.item(0);
   
    this.date = new Date();
    let dateString = `_${this.date.getTime()}_${this.date.getDate()}_${this.date.getFullYear()}`
    if (this.currentFileUpload.type == 'image/png') {
      this.profilePic = `${this.userName}${dateString}.png`;
    }
    if (this.currentFileUpload.type == 'image/jpeg' || this.currentFileUpload.type == 'image/jpg') {
      this.profilePic = `${this.userName}${dateString}.jpeg`;
    }
    console.log(this.profilePic);
    console.log(this.userName);
    this.uploadService.pushFileToStorage(this.currentFileUpload,this.userName,this.password,this.email,this.profilePic).subscribe((event:HttpEvent<{}>) => {

  
      this.router.navigate(['/login']); });

   }
   }
// list of files selected

    // loop around to work on all files

  // reads the content of file, so that it can be used for preview
  // without saving it to angular application folder
  

  ngOnInit() {
    this.userId = this.auth.getUserDetails();
    this.ser.getAllUsers().subscribe((responce:any)=>{this.userlist=responce;console.log(responce)});
  }

}
