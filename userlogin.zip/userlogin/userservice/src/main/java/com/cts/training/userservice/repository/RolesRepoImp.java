package com.cts.training.userservice.repository;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.training.userservice.entity.Roles;

@Repository
@Transactional

public class RolesRepoImp implements RolesRepository {
	@PersistenceContext
	private EntityManager em;
	@Override
	public void save(Roles role) {
	this.em.persist(role);

}
}