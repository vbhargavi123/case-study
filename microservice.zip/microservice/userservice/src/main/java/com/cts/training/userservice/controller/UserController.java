package com.cts.training.userservice.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.cts.training.userservice.entity.User;
import com.cts.training.userservice.repository.UserRepository;
import com.cts.training.userservice.service.IUserService;

@RestController
public class UserController {

	// dependency
	@Autowired
	private IUserService userService;
	
	// REST method that will recieve a movie Id and return details of that movie
	// ENDPOINT : /movies/{movieId}
	@GetMapping("/users")
public ResponseEntity<List<User>> exposeAll() {
		
		List<User> users = this.userService.findAllUsers();
		ResponseEntity<List<User>> response = 
								new ResponseEntity<List<User>>(users, HttpStatus.OK);
		
		
		return response;

	}
	@GetMapping("/users/{userId}") // GET HTTP VERB
	public ResponseEntity<User> getById(@PathVariable Integer userId) {
		
		User user = this.userService.findUserById(userId);
		ResponseEntity<User> response = 
				new ResponseEntity<User>(user, HttpStatus.OK);

		return response;
	}
	@PutMapping("/users")
	public ResponseEntity<User> saveUpdate(@RequestBody User user) {
		this.userService.updateUser(user);
			
		ResponseEntity<User> response = 
				new ResponseEntity<User>(user, HttpStatus.OK);

		return response;
	}
	
	@DeleteMapping("/users/{userId}")
	public ResponseEntity<User> delete(@PathVariable Integer userId) {
		
		User user = this.userService.findUserById(userId);
		this.userService.deleteUser(userId);
		
		ResponseEntity<User> response = 
				new ResponseEntity<User>(user, HttpStatus.OK);

		return response;
	}
	
}

	














