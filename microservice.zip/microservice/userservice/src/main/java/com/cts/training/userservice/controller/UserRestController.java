package com.cts.training.userservice.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.userservice.entity.User;
import com.cts.training.userservice.exception.UserErrorResponse;
import com.cts.training.userservice.exception.UserNotFoundException;
import com.cts.training.userservice.service.IUserService;

@RestController
@RequestMapping("/api")
@CrossOrigin("http://localhost:4200")
public class UserRestController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	// dependency
	@Autowired
	private IUserService userService;
	
	// @RequestMapping(value =  "/users", method = {RequestMethod.GET, RequestMethod.PUT} )
	@GetMapping("/users") // GET HTTP VERB
	public ResponseEntity<List<User>> exposeAll() {
		
		List<User> users = this.userService.findAllUsers();
		// if(users.size() == 0)
		if(users == null)
			throw new UserNotFoundException("Not able to fetch records!!!");
		ResponseEntity<List<User>> response = 
								new ResponseEntity<List<User>>(users, HttpStatus.OK);
		
		
		return response;
	}
	
	// {<data variable>}
	@GetMapping("/users/{userId}") // GET HTTP VERB
	public ResponseEntity<User> getById(@PathVariable Integer userId) {
		
		User user = this.userService.findUserById(userId);
		if(user == null)
			throw new UserNotFoundException("User with id-" + userId + " not Found");
		
		ResponseEntity<User> response = 
				new ResponseEntity<User>(user, HttpStatus.OK);

		return response;
	}
	
	// @RequestMapping(value =  "/users", method = RequestMethod.POST)
	@PostMapping("/users") // POST HTTP VERB
	public ResponseEntity<User> save(@RequestBody User user) {
		if(!this.userService.addUser(user))
			throw new RuntimeException("Could not add new record!!!");
		ResponseEntity<User> response = 
				new ResponseEntity<User>(user, HttpStatus.OK);

		return response;
	}
	
	@PutMapping("/usersId")
	public ResponseEntity<User> saveUpdate(@RequestBody User user,@PathVariable Integer userId) {
		if(!this.userService.updateUser(user))
			throw new RuntimeException("Could not update record!!!");
		ResponseEntity<User> response = 
				new ResponseEntity<User>(user, HttpStatus.OK);

		return response;
	}
	
	@DeleteMapping("/users/{userId}")
	public ResponseEntity<User> delete(@PathVariable Integer userId) {
		
		User user = this.userService.findUserById(userId);
		if(user == null)
			throw new UserNotFoundException("User with id-" + userId + " not Found");
		
		// send userId to DAO via SERVICE
		this.userService.deleteUser(userId);
		
		ResponseEntity<User> response = 
				new ResponseEntity<User>(user, HttpStatus.OK);

		return response;
	}
	
	
	// for exception handling
	@ExceptionHandler  // ~catch
	public ResponseEntity<UserErrorResponse> userNotFoundHandler(UserNotFoundException ex) {
		// create error object
		UserErrorResponse error = new UserErrorResponse(ex.getMessage(), 
															  HttpStatus.NOT_FOUND.value(), 
															  System.currentTimeMillis());
		ResponseEntity<UserErrorResponse> response =
										new ResponseEntity<UserErrorResponse>(error, HttpStatus.NOT_FOUND);
		
		return response;
	}
	
	@ExceptionHandler  // ~catch
	public ResponseEntity<UserErrorResponse> userOperationErrorHAndler(Exception ex) {
		// create error object
		UserErrorResponse error = new UserErrorResponse(ex.getMessage(), 
															  HttpStatus.BAD_REQUEST.value(), 
															  System.currentTimeMillis());
		ResponseEntity<UserErrorResponse> response =
										new ResponseEntity<UserErrorResponse>(error, HttpStatus.NOT_FOUND);
		logger.error("Exception :" + error);
		
		return response;
	}
	
	
	
	/************ REST endpoints ************/
	// /api/user [GET]
	// /api/user/id [GET]
	// /api/user [POST]
	// /api/user [PUT]
	// /api/user/id [DELETE]
	
	
	
	
}
