package com.cts.training.actionservice.service;

import java.util.List;

import com.cts.training.actionservice.entity.Action;



public interface IActionService {
	List<Action> findAllactions();
	Action findactionById(Integer id);
	boolean addaction(Action student);
	boolean updateaction(Action student);
	boolean deleteaction(Integer id);
}
