package com.cts.training.Newsfeedservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.training.Newsfeedservice.entity.Newsfeed;



@Repository
public interface NewsfeedRepository extends JpaRepository<Newsfeed,Integer>{

}
