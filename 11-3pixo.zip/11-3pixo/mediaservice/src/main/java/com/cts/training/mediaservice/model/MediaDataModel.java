package com.cts.training.mediaservice.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class MediaDataModel {
	
	private Integer userId; 
	private String title;
	private String description;
	private String tags;
	private String type;
	private String url;


}
