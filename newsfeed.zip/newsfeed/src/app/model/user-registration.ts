export class UserRegistrationDetails{
    
        id : number;
        
    
        userName : string;
        email : string;
        password : string;
        profilePic : any;
    
        constructor(userName,email,password,profilePic){
        
            
            this.userName =  userName;
            this.email = email;
            this.password = password;
            this.profilePic = profilePic;
        }
    }