package com.cts.training.userservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cts.training.userservice.entity.User;
import com.cts.training.userservice.model.SearchedUserModelList;
import com.cts.training.userservice.model.UserInput;
import com.cts.training.userservice.model.UserOutput;



@Service
public interface IUserService {
public	List<User> findAllUsers();
public	Optional<User> findUserById(Integer id);
	public void addUser(UserInput userInput);
	public void updateUser(UserOutput user);
	public SearchedUserModelList searchUsers(String searchString);
	//boolean deleteUser(Integer id);
}
