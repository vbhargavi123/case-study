package com.cts.training.userservice.model;


import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UserInput {
	private Integer id;
	private String username;
	private String password;
	private String repassword;
	private String email;
}
